import { useState, useEffect } from 'react';
import { 
  Moon, 
  Sun, 
  BookOpen, 
  Heart, 
  HandHeart, 
  Sparkles, 
  Music, 
  Download,
  CheckCircle2,
  Circle,
  TrendingUp,
  Calendar,
  Clock,
  Star,
  Play,
  Pause
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import './App.css';

// Types
interface IbadahActivity {
  id: string;
  name: string;
  category: string;
  completed: boolean;
  icon: React.ReactNode;
}

interface JuzData {
  number: number;
  name: string;
  startSurah: string;
  endSurah: string;
  verses: string;
  audioUrl: string;
}

// Quran Juz Data
const quranJuzData: JuzData[] = [
  { number: 1, name: "Alif Lam Meem", startSurah: "Al-Fatiha", endSurah: "Al-Baqarah", verses: "1:1 - 2:141", audioUrl: "#" },
  { number: 2, name: "Sayaqool", startSurah: "Al-Baqarah", endSurah: "Al-Baqarah", verses: "2:142 - 2:252", audioUrl: "#" },
  { number: 3, name: "Tilkal Rusulu", startSurah: "Al-Baqarah", endSurah: "Aali Imran", verses: "2:253 - 3:92", audioUrl: "#" },
  { number: 4, name: "Lan Tanaloo", startSurah: "Aali Imran", endSurah: "An-Nisa", verses: "3:93 - 4:23", audioUrl: "#" },
  { number: 5, name: "Wal Mohsanat", startSurah: "An-Nisa", endSurah: "An-Nisa", verses: "4:24 - 4:147", audioUrl: "#" },
  { number: 6, name: "La Yuhibbullah", startSurah: "An-Nisa", endSurah: "Al-Ma'idah", verses: "4:148 - 5:81", audioUrl: "#" },
  { number: 7, name: "Wa Iza Samiu", startSurah: "Al-Ma'idah", endSurah: "Al-An'am", verses: "5:82 - 6:110", audioUrl: "#" },
  { number: 8, name: "Wa Lau Annana", startSurah: "Al-An'am", endSurah: "Al-A'raf", verses: "6:111 - 7:87", audioUrl: "#" },
  { number: 9, name: "Qalal Malao", startSurah: "Al-A'raf", endSurah: "Al-Anfal", verses: "7:88 - 8:40", audioUrl: "#" },
  { number: 10, name: "Wa A'lamu", startSurah: "Al-Anfal", endSurah: "At-Tawbah", verses: "8:41 - 9:92", audioUrl: "#" },
  { number: 11, name: "Yatazeroon", startSurah: "At-Tawbah", endSurah: "Yunus", verses: "9:93 - 10:109", audioUrl: "#" },
  { number: 12, name: "Wa Mamin Da'abba", startSurah: "Hud", endSurah: "Yusuf", verses: "11:1 - 12:52", audioUrl: "#" },
  { number: 13, name: "Wa Ma Ubrioo", startSurah: "Yusuf", endSurah: "Ibrahim", verses: "12:53 - 14:52", audioUrl: "#" },
  { number: 14, name: "Rubama", startSurah: "Al-Hijr", endSurah: "An-Nahl", verses: "15:1 - 16:128", audioUrl: "#" },
  { number: 15, name: "Subhanallazi", startSurah: "Al-Isra", endSurah: "Al-Kahf", verses: "17:1 - 18:74", audioUrl: "#" },
  { number: 16, name: "Qal Alam", startSurah: "Al-Kahf", endSurah: "Maryam", verses: "18:75 - 20:135", audioUrl: "#" },
  { number: 17, name: "Aqtarabat", startSurah: "Al-Anbiya", endSurah: "Al-Hajj", verses: "21:1 - 22:78", audioUrl: "#" },
  { number: 18, name: "Qad Aflaha", startSurah: "Al-Mu'minun", endSurah: "An-Nur", verses: "23:1 - 25:20", audioUrl: "#" },
  { number: 19, name: "Wa Qalallazina", startSurah: "Al-Furqan", endSurah: "An-Naml", verses: "25:21 - 27:55", audioUrl: "#" },
  { number: 20, name: "A'man Khalaq", startSurah: "An-Naml", endSurah: "Al-Ankabut", verses: "27:56 - 29:45", audioUrl: "#" },
  { number: 21, name: "Utlu Ma Oohiya", startSurah: "Al-Ankabut", endSurah: "Luqman", verses: "29:46 - 31:34", audioUrl: "#" },
  { number: 22, name: "Wa Manyaqnut", startSurah: "As-Sajda", endSurah: "Al-Ahzab", verses: "32:1 - 33:30", audioUrl: "#" },
  { number: 23, name: "Wa Mali", startSurah: "Al-Ahzab", endSurah: "Ya Sin", verses: "33:31 - 36:27", audioUrl: "#" },
  { number: 24, name: "Faman Azlam", startSurah: "Ya Sin", endSurah: "Az-Zumar", verses: "36:28 - 39:31", audioUrl: "#" },
  { number: 25, name: "Ilayhi Yuraddu", startSurah: "Az-Zumar", endSurah: "Fussilat", verses: "39:32 - 41:46", audioUrl: "#" },
  { number: 26, name: "Ha Meem", startSurah: "Fussilat", endSurah: "Al-Jathiya", verses: "41:47 - 45:37", audioUrl: "#" },
  { number: 27, name: "Qala Fama Khatbukum", startSurah: "Al-Ahqaf", endSurah: "Al-Fath", verses: "46:1 - 51:30", audioUrl: "#" },
  { number: 28, name: "Qad Sami'allah", startSurah: "Adh-Dhariyat", endSurah: "Al-Hadid", verses: "51:31 - 57:29", audioUrl: "#" },
  { number: 29, name: "Tabarakallazi", startSurah: "Al-Mujadila", endSurah: "At-Tahrim", verses: "58:1 - 66:12", audioUrl: "#" },
  { number: 30, name: "Amma", startSurah: "Al-Mulk", endSurah: "An-Nas", verses: "67:1 - 114:6", audioUrl: "#" },
];

// Ibadah Activities Data
const defaultActivities: IbadahActivity[] = [
  { id: 'fajr', name: 'Fajr Prayer', category: 'prayer', completed: false, icon: <Sun className="w-5 h-5" /> },
  { id: 'dhuhr', name: 'Dhuhr Prayer', category: 'prayer', completed: false, icon: <Sun className="w-5 h-5" /> },
  { id: 'asr', name: 'Asr Prayer', category: 'prayer', completed: false, icon: <Sun className="w-5 h-5" /> },
  { id: 'maghrib', name: 'Maghrib Prayer', category: 'prayer', completed: false, icon: <Moon className="w-5 h-5" /> },
  { id: 'isha', name: 'Isha Prayer', category: 'prayer', completed: false, icon: <Moon className="w-5 h-5" /> },
  { id: 'taraweeh', name: 'Taraweeh Prayer', category: 'prayer', completed: false, icon: <Sparkles className="w-5 h-5" /> },
  { id: 'fasting', name: 'Daily Fasting', category: 'fasting', completed: false, icon: <Calendar className="w-5 h-5" /> },
  { id: 'quran-juz', name: 'Read 1 Juz of Quran', category: 'quran', completed: false, icon: <BookOpen className="w-5 h-5" /> },
  { id: 'quran-reflection', name: 'Quran Reflection', category: 'quran', completed: false, icon: <BookOpen className="w-5 h-5" /> },
  { id: 'morning-dhikr', name: 'Morning Dhikr', category: 'dhikr', completed: false, icon: <Heart className="w-5 h-5" /> },
  { id: 'evening-dhikr', name: 'Evening Dhikr', category: 'dhikr', completed: false, icon: <Heart className="w-5 h-5" /> },
  { id: 'istighfar', name: 'Istighfar (100x)', category: 'dhikr', completed: false, icon: <Heart className="w-5 h-5" /> },
  { id: 'salawat', name: 'Salawat on Prophet (PBUH)', category: 'dhikr', completed: false, icon: <Heart className="w-5 h-5" /> },
  { id: 'dua-list', name: 'Daily Dua List', category: 'dua', completed: false, icon: <HandHeart className="w-5 h-5" /> },
  { id: 'tahajjud', name: 'Tahajjud/Qiyam', category: 'prayer', completed: false, icon: <Star className="w-5 h-5" /> },
  { id: 'sadaqah', name: 'Charity/Sadaqah', category: 'charity', completed: false, icon: <HandHeart className="w-5 h-5" /> },
  { id: 'help-others', name: 'Help Someone', category: 'charity', completed: false, icon: <HandHeart className="w-5 h-5" /> },
  { id: 'family-time', name: 'Quality Family Time', category: 'family', completed: false, icon: <Heart className="w-5 h-5" /> },
];

function App() {
  const [activities, setActivities] = useState<IbadahActivity[]>(defaultActivities);
  const [playingJuz, setPlayingJuz] = useState<number | null>(null);
  const [selectedDay] = useState<number>(new Date().getDate());

  // Load data from localStorage on mount
  useEffect(() => {
    const savedActivities = localStorage.getItem('ramadan-activities');
    
    if (savedActivities) {
      setActivities(JSON.parse(savedActivities));
    }
  }, []);

  // Save to localStorage when activities change
  useEffect(() => {
    localStorage.setItem('ramadan-activities', JSON.stringify(activities));
  }, [activities]);

  const toggleActivity = (id: string) => {
    setActivities(prev => 
      prev.map(activity => 
        activity.id === id ? { ...activity, completed: !activity.completed } : activity
      )
    );
    
    const activity = activities.find(a => a.id === id);
    if (activity) {
      toast.success(`${activity.name} ${activity.completed ? 'unchecked' : 'completed'}!`, {
        duration: 2000,
      });
    }
  };

  const completedCount = activities.filter(a => a.completed).length;
  const progressPercentage = Math.round((completedCount / activities.length) * 100);

  const getCategoryProgress = (category: string) => {
    const categoryActivities = activities.filter(a => a.category === category);
    const completed = categoryActivities.filter(a => a.completed).length;
    return { total: categoryActivities.length, completed };
  };

  const categories = [
    { id: 'prayer', name: 'Prayers', icon: <Moon className="w-5 h-5" />, color: 'from-emerald-500 to-teal-500' },
    { id: 'fasting', name: 'Fasting', icon: <Calendar className="w-5 h-5" />, color: 'from-amber-500 to-orange-500' },
    { id: 'quran', name: 'Quran', icon: <BookOpen className="w-5 h-5" />, color: 'from-blue-500 to-cyan-500' },
    { id: 'dhikr', name: 'Dhikr', icon: <Heart className="w-5 h-5" />, color: 'from-rose-500 to-pink-500' },
    { id: 'dua', name: 'Dua', icon: <HandHeart className="w-5 h-5" />, color: 'from-violet-500 to-purple-500' },
    { id: 'charity', name: 'Charity', icon: <HandHeart className="w-5 h-5" />, color: 'from-green-500 to-emerald-500' },
    { id: 'family', name: 'Family', icon: <Heart className="w-5 h-5" />, color: 'from-yellow-500 to-amber-500' },
  ];

  const handleDownload = (juz: JuzData) => {
    toast.info(`Downloading Juz ${juz.number} - ${juz.name}...`, {
      duration: 3000,
    });
    // In a real app, this would trigger an actual download
  };

  const handlePlay = (juzNumber: number) => {
    if (playingJuz === juzNumber) {
      setPlayingJuz(null);
      toast.info('Audio paused');
    } else {
      setPlayingJuz(juzNumber);
      toast.success(`Playing Juz ${juzNumber}`);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-islamic pattern-islamic">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 backdrop-blur-xl bg-background/80 border-b border-border/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="crescent-moon w-10 h-10 scale-50" />
              <span className="font-amiri text-2xl font-bold text-gradient-gold">Ramadan Tracker</span>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant="outline" className="border-amber-500/50 text-amber-400">
                <Calendar className="w-4 h-4 mr-1" />
                Day {selectedDay} of Ramadan
              </Badge>
              <div className="hidden sm:flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="w-4 h-4" />
                <span>{new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}</span>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 sm:py-32">
        <div className="absolute inset-0 stars-bg opacity-50" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="animate-float mb-8">
            <div className="crescent-moon mx-auto w-24 h-24" />
          </div>
          <h1 className="font-amiri text-5xl sm:text-6xl lg:text-7xl font-bold text-gradient-gold mb-6">
            Ramadan Mubarak
          </h1>
          <p className="text-xl sm:text-2xl text-muted-foreground max-w-2xl mx-auto mb-8">
            Track your daily ibadah, download Quran audio by Juz, and make the most of this blessed month
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" className="bg-gradient-to-r from-amber-500 to-yellow-500 text-background hover:from-amber-600 hover:to-yellow-600 glow-gold">
              <Sparkles className="w-5 h-5 mr-2" />
              Start Your Journey
            </Button>
            <Button size="lg" variant="outline" className="border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/10">
              <BookOpen className="w-5 h-5 mr-2" />
              Explore Quran
            </Button>
          </div>
        </div>
      </section>

      {/* Progress Overview */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <Card className="bg-gradient-card border-gold overflow-hidden">
            <CardContent className="p-6 sm:p-8">
              <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
                <div className="text-center lg:text-left">
                  <h2 className="text-2xl font-bold text-gradient-gold mb-2">Today's Progress</h2>
                  <p className="text-muted-foreground">Keep up the good work! Every deed counts in this blessed month.</p>
                </div>
                <div className="flex items-center gap-8">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-gradient-gold">{completedCount}</div>
                    <div className="text-sm text-muted-foreground">Completed</div>
                  </div>
                  <div className="w-32 sm:w-48">
                    <Progress value={progressPercentage} className="h-3 bg-secondary" />
                    <div className="text-center mt-2 text-sm font-medium text-amber-400">{progressPercentage}%</div>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold text-emerald-400">{activities.length}</div>
                    <div className="text-sm text-muted-foreground">Total</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Main Content Tabs */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <Tabs defaultValue="ibadah" className="w-full">
            <TabsList className="w-full max-w-md mx-auto mb-8 bg-secondary/50 p-1">
              <TabsTrigger value="ibadah" className="flex-1 data-[state=active]:bg-gradient-to-r data-[state=active]:from-amber-500/20 data-[state=active]:to-yellow-500/20 data-[state=active]:text-amber-400">
                <CheckCircle2 className="w-4 h-4 mr-2" />
                Ibadah Tracker
              </TabsTrigger>
              <TabsTrigger value="quran" className="flex-1 data-[state=active]:bg-gradient-to-r data-[state=active]:from-emerald-500/20 data-[state=active]:to-teal-500/20 data-[state=active]:text-emerald-400">
                <Music className="w-4 h-4 mr-2" />
                Quran Audio
              </TabsTrigger>
              <TabsTrigger value="progress" className="flex-1 data-[state=active]:bg-gradient-to-r data-[state=active]:from-violet-500/20 data-[state=active]:to-purple-500/20 data-[state=active]:text-violet-400">
                <TrendingUp className="w-4 h-4 mr-2" />
                Progress
              </TabsTrigger>
            </TabsList>

            {/* Ibadah Tracker Tab */}
            <TabsContent value="ibadah" className="space-y-6">
              {/* Category Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-4 mb-8">
                {categories.map((cat) => {
                  const progress = getCategoryProgress(cat.id);
                  return (
                    <Card key={cat.id} className="bg-gradient-card border-border/50 hover-lift cursor-pointer">
                      <CardContent className="p-4 text-center">
                        <div className={`w-10 h-10 mx-auto mb-2 rounded-lg bg-gradient-to-r ${cat.color} flex items-center justify-center text-white`}>
                          {cat.icon}
                        </div>
                        <div className="text-sm font-medium">{cat.name}</div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {progress.completed}/{progress.total}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              {/* Activity Checklist */}
              <Card className="bg-gradient-card border-border/50">
                <CardHeader>
                  <CardTitle className="text-xl font-amiri text-gradient-gold">Daily Ibadah Checklist</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-3">
                    {activities.map((activity) => (
                      <div
                        key={activity.id}
                        onClick={() => toggleActivity(activity.id)}
                        className={`flex items-center gap-4 p-4 rounded-lg cursor-pointer transition-all duration-200 ${
                          activity.completed 
                            ? 'bg-emerald-500/10 border border-emerald-500/30' 
                            : 'bg-secondary/30 border border-transparent hover:bg-secondary/50'
                        }`}
                      >
                        <div className={`flex-shrink-0 ${activity.completed ? 'text-emerald-400' : 'text-muted-foreground'}`}>
                          {activity.completed ? <CheckCircle2 className="w-6 h-6" /> : <Circle className="w-6 h-6" />}
                        </div>
                        <div className={`flex-shrink-0 ${activity.completed ? 'text-emerald-400' : 'text-amber-400'}`}>
                          {activity.icon}
                        </div>
                        <span className={`flex-1 ${activity.completed ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
                          {activity.name}
                        </span>
                        <Badge variant="outline" className="text-xs capitalize">
                          {activity.category}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Quran Audio Tab */}
            <TabsContent value="quran" className="space-y-6">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-amiri text-gradient-gold mb-2">Quran Audio by Juz</h2>
                <p className="text-muted-foreground">Download or listen to the complete Quran divided into 30 Juz</p>
              </div>

              <div className="grid gap-4">
                {quranJuzData.map((juz) => (
                  <Card key={juz.number} className="bg-gradient-card border-border/50 hover-lift">
                    <CardContent className="p-4 sm:p-6">
                      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                        <div className="flex-shrink-0 w-16 h-16 rounded-xl bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 flex items-center justify-center">
                          <span className="text-2xl font-bold text-emerald-400">{juz.number}</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="text-lg font-semibold text-foreground">{juz.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {juz.startSurah} {juz.startSurah !== juz.endSurah && `- ${juz.endSurah}`}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">{juz.verses}</p>
                        </div>
                        <div className="flex gap-2 w-full sm:w-auto">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handlePlay(juz.number)}
                            className={`flex-1 sm:flex-none ${playingJuz === juz.number ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50' : ''}`}
                          >
                            {playingJuz === juz.number ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                            {playingJuz === juz.number ? 'Pause' : 'Play'}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDownload(juz)}
                            className="flex-1 sm:flex-none border-amber-500/50 text-amber-400 hover:bg-amber-500/10"
                          >
                            <Download className="w-4 h-4 mr-2" />
                            Download
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Progress Tab */}
            <TabsContent value="progress" className="space-y-6">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-amiri text-gradient-gold mb-2">Your Ramadan Journey</h2>
                <p className="text-muted-foreground">Track your progress throughout the blessed month</p>
              </div>

              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                <Card className="bg-gradient-card border-gold">
                  <CardContent className="p-6 text-center">
                    <div className="text-4xl font-bold text-gradient-gold mb-2">{completedCount}</div>
                    <div className="text-sm text-muted-foreground">Today's Completed</div>
                  </CardContent>
                </Card>
                <Card className="bg-gradient-card border-emerald-500/30">
                  <CardContent className="p-6 text-center">
                    <div className="text-4xl font-bold text-emerald-400 mb-2">
                      {activities.filter(a => a.category === 'prayer' && a.completed).length}
                    </div>
                    <div className="text-sm text-muted-foreground">Prayers Completed</div>
                  </CardContent>
                </Card>
                <Card className="bg-gradient-card border-blue-500/30">
                  <CardContent className="p-6 text-center">
                    <div className="text-4xl font-bold text-blue-400 mb-2">
                      {activities.filter(a => a.category === 'quran' && a.completed).length}
                    </div>
                    <div className="text-sm text-muted-foreground">Quran Activities</div>
                  </CardContent>
                </Card>
                <Card className="bg-gradient-card border-rose-500/30">
                  <CardContent className="p-6 text-center">
                    <div className="text-4xl font-bold text-rose-400 mb-2">
                      {activities.filter(a => a.category === 'dhikr' && a.completed).length}
                    </div>
                    <div className="text-sm text-muted-foreground">Dhikr Completed</div>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-gradient-card border-border/50">
                <CardHeader>
                  <CardTitle className="text-lg font-amiri text-gradient-gold">Category Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {categories.map((cat) => {
                      const progress = getCategoryProgress(cat.id);
                      const percentage = progress.total > 0 ? (progress.completed / progress.total) * 100 : 0;
                      return (
                        <div key={cat.id} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className={`w-8 h-8 rounded-lg bg-gradient-to-r ${cat.color} flex items-center justify-center text-white`}>
                                {cat.icon}
                              </div>
                              <span className="font-medium">{cat.name}</span>
                            </div>
                            <span className="text-sm text-muted-foreground">
                              {progress.completed}/{progress.total}
                            </span>
                          </div>
                          <Progress value={percentage} className="h-2 bg-secondary" />
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 sm:px-6 lg:px-8 border-t border-border/50">
        <div className="max-w-7xl mx-auto text-center">
          <div className="crescent-moon mx-auto w-12 h-12 scale-50 mb-4" />
          <p className="font-amiri text-2xl text-gradient-gold mb-2">Ramadan Mubarak</p>
          <p className="text-muted-foreground text-sm mb-4">
            May Allah accept your fasting, prayers, and good deeds
          </p>
          <Separator className="my-6 bg-border/50" />
          <p className="text-xs text-muted-foreground">
            Designed with love for the Ummah
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
